package com.example.moneymindbudgetapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budget_entries")
data class BudgetEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String,
    val amount: Double,
    val photoPath: String?,
    val minGoal: Double,
    val maxGoal: Double,
    val date: Long // save date as timestamp
)
