package com.example.moneymindbudgetapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.moneymindbudgetapp.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Login : AppCompatActivity() {
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        db = AppDatabase.getDatabase(this)

        val email = findViewById<EditText>(R.id.etEmailLogin)
        val password = findViewById<EditText>(R.id.etPasswordLogin)

        findViewById<Button>(R.id.btnNextLogin).setOnClickListener {
            val userEmail = email.text.toString()
            val userPassword = password.text.toString()

            lifecycleScope.launch(Dispatchers.IO) {
                val user = db.userDao().login(userEmail, userPassword)
                runOnUiThread {
                    if (user != null) {
                        Toast.makeText(this@Login, "Login Successful", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@Login, DataInput::class.java))
                    } else {
                        Toast.makeText(this@Login, "Invalid Credentials", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        findViewById<Button>(R.id.btnBackLogin).setOnClickListener {
            finish()
        }
    }
}
