package com.example.moneymindbudgetapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.example.moneymindbudgetapp.data.AppDatabase
import com.example.moneymindbudgetapp.data.BudgetEntryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

class DataInput : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private lateinit var currentPhotoPath: String
    private val REQUEST_IMAGE_CAPTURE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_input)

        db = AppDatabase.getDatabase(this)

        val category = findViewById<EditText>(R.id.etCategory)
        val amount = findViewById<EditText>(R.id.etAmount)
        val minGoal = findViewById<EditText>(R.id.etMinGoal)
        val maxGoal = findViewById<EditText>(R.id.etMaxGoal)

        findViewById<Button>(R.id.btnNextDataInput).setOnClickListener {
            val entry = BudgetEntryEntity(
                category = category.text.toString(),
                amount = amount.text.toString().toDouble(),
                photoPath = if (::currentPhotoPath.isInitialized) currentPhotoPath else null,
                minGoal = minGoal.text.toString().toDouble(),
                maxGoal = maxGoal.text.toString().toDouble(),
                date = System.currentTimeMillis()
            )

            lifecycleScope.launch(Dispatchers.IO) {
                db.budgetDao().insertBudgetEntry(entry)
                runOnUiThread {
                    Toast.makeText(this@DataInput, "Entry Saved", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@DataInput, Display::class.java))
                }
            }
        }

        findViewById<Button>(R.id.btnTakePhoto).setOnClickListener {
            dispatchTakePictureIntent()
        }

        findViewById<Button>(R.id.btnHomeDataInput).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            val photoFile = createImageFile()
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                photoFile
            )
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
        }
    }

    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            Toast.makeText(this, "Photo Taken", Toast.LENGTH_SHORT).show()
        }
    }
}
