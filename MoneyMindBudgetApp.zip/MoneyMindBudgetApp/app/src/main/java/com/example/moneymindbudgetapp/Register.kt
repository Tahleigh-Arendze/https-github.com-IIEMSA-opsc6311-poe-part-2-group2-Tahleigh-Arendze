package com.example.moneymindbudgetapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.moneymindbudgetapp.data.AppDatabase
import com.example.moneymindbudgetapp.data.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Register : AppCompatActivity() {
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        db = AppDatabase.getDatabase(this)

        val firstName = findViewById<EditText>(R.id.etFirstName)
        val email = findViewById<EditText>(R.id.etEmail)
        val password = findViewById<EditText>(R.id.etPassword)

        findViewById<Button>(R.id.btnNextRegister).setOnClickListener {
            val user = UserEntity(
                firstName = firstName.text.toString(),
                email = email.text.toString(),
                password = password.text.toString()
            )

            lifecycleScope.launch(Dispatchers.IO) {
                db.userDao().insertUser(user)
                runOnUiThread {
                    Toast.makeText(this@Register, "Registered Successfully", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@Register, Login::class.java))
                }
            }
        }

        findViewById<Button>(R.id.btnBackRegister).setOnClickListener {
            finish()
        }
    }
}
