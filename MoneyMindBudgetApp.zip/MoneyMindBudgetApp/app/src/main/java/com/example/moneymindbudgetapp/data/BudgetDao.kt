package com.example.moneymindbudgetapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface BudgetDao {
    @Insert
    suspend fun insertBudgetEntry(entry: BudgetEntryEntity)

    @Query("SELECT * FROM budget_entries WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getEntriesByPeriod(startDate: Long, endDate: Long): List<BudgetEntryEntity>
}
