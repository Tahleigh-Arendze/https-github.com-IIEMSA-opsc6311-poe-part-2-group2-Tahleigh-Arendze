package com.example.moneymindbudgetapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.moneymindbudgetapp.data.BudgetEntryEntity
import java.io.File

class BudgetEntryAdapter(context: Context, private val entries: List<BudgetEntryEntity>) :
    ArrayAdapter<BudgetEntryEntity>(context, 0, entries) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var listItemView = convertView
        if (listItemView == null) {
            listItemView = LayoutInflater.from(context).inflate(R.layout.entry_item, parent, false)
        }

        val entry = entries[position]

        listItemView!!.findViewById<TextView>(R.id.categoryText).text = entry.category
        listItemView.findViewById<TextView>(R.id.amountText).text = "R${entry.amount}"

        val viewPhotoBtn = listItemView.findViewById<Button>(R.id.viewPhotoButton)

        if (entry.photoPath.isNullOrEmpty()) {
            viewPhotoBtn.visibility = View.GONE
        } else {
            viewPhotoBtn.visibility = View.VISIBLE
            viewPhotoBtn.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW)
                intent.setDataAndType(Uri.fromFile(File(entry.photoPath)), "image/*")
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.startActivity(intent)
            }
        }

        return listItemView
    }
}
