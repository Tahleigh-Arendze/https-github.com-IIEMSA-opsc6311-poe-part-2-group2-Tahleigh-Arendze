package com.example.moneymindbudgetapp

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.moneymindbudgetapp.data.AppDatabase
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class Display : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private lateinit var entriesListView: ListView
    private lateinit var totalTextView: TextView
    private lateinit var periodTextView: TextView

    private var startDate: Long = 0
    private var endDate: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display)

        db = AppDatabase.getDatabase(this)

        entriesListView = findViewById(R.id.entriesListView)
        totalTextView = findViewById(R.id.totalTextView)
        periodTextView = findViewById(R.id.periodTextView)

        findViewById<Button>(R.id.btnHomeDisplay).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        findViewById<Button>(R.id.btnSelectPeriod).setOnClickListener {
            selectStartDate()
        }

        // Set default period (this month)
        startDate = getStartOfMonth()
        endDate = getEndOfMonth()
        loadEntries()
    }

    private fun loadEntries() {
        lifecycleScope.launch {
            val entries = db.budgetDao().getEntriesByPeriod(startDate, endDate)
            val adapter = BudgetEntryAdapter(this@Display, entries)
            entriesListView.adapter = adapter

            val total = entries.sumOf { it.amount }
            totalTextView.text = "Total: R$total"

            val grouped = entries.groupBy { it.category }
            val categoryTotals = grouped.map { "${it.key}: R${it.value.sumOf { e -> e.amount }}" }
            periodTextView.text = "Period Total by Category:\n" + categoryTotals.joinToString("\n")
        }
    }

    private fun selectStartDate() {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, dayOfMonth ->
            calendar.set(year, month, dayOfMonth, 0, 0, 0)
            startDate = calendar.timeInMillis
            selectEndDate()
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun selectEndDate() {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, dayOfMonth ->
            calendar.set(year, month, dayOfMonth, 23, 59, 59)
            endDate = calendar.timeInMillis
            loadEntries()
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun getStartOfMonth(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return calendar.timeInMillis
    }

    private fun getEndOfMonth(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        return calendar.timeInMillis
    }
}
